#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tues Ago  16 12:26:53 2022

@author: Moises Zeleny (moiseszeleny@gmail.com)

Tools for numeric evaluation for diagrams
"""

