#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul  8 01:07:53 2020

@author: Moises Zeleny (moiseszeleny@gmail.com)

The symbolic formalism of LFV Higgs decays is coded in this module
"""
from sympy import Function, symbols, solve, polylog, I, simplify, pi
from sympy import Mul, Indexed
from sympy import sqrt, collect, Add, log, conjugate, re, integrate
from sympy import lambdify, Symbol
from scipy.special import spence
import numpy as np

# ###########################################
# Masas del higgs tipo SM, m1 y m2 masas de los leptones finales y
# delta parámetro infinitesimal para las integrales de Passarivo Veltman
# ###########################################
m0 = 'm_a'  # input('Initial particle mass ma: ')
m1 = 'm_i'  # input('Final particle mass mi: ')
m2 = 'm_j'  # input('Final particle mass mj: ')

ma = symbols(fr'{m0}', positive=True)
mi = symbols(fr'{m1}', positive=True)
mj = symbols(fr'{m2}', positive=True)

δ = 0


def sci_polylog(s, z):
    '''
    Definition for the polilogarithm
    '''
    return spence(1-z)
#######################################
# Funciones de Passarino Veltman pertinentes para LFVHD
#######################################


# Funciones de PaVe escalares
A0 = Function('A_0')
B0 = Function('B_0')
B1_0 = Function('{{B^{(1)}_{0}}}')
B2_0 = Function('{{B^{(2)}_{0}}}')
B1_1 = Function('{{B^{(1)}_{1}}}')
B2_1 = Function('{{B^{(2)}_{1}}}')
B12_0 = Function('{{B^{(12)}_{0}}}')
B12_1 = Function('{{B^{(12)}_{1}}}')
B12_2 = Function('{{B^{(12)}_{2}}}')
C0 = Function('C_0')
C1 = Function('C_1')
C2 = Function('C_2')

# Adding factor from RD


# Partes finitas de las funciones de PaVe en la aproximación p_i^2 = 0
a0 = Function('a_0')
b1_0 = Function('{{b^{(1)}_0}}')
b2_0 = Function('{{b^{(2)}_0}}')
b1_1 = Function('{{b^{(1)}_1}}')
b2_1 = Function('{{b^{(2)}_1}}')
b12_0 = Function('{{b^{(12)}_0}}')
b12_1 = Function('{{b^{(12)}_1}}')
b12_2 = Function('{{b^{(12)}_2}}')

# Función simbolica para las divergencias
# Div=Function('Div')

# Definiendo divergencias
Δe = symbols(r'\Delta_\epsilon')


class Div(Function):
    '''Subclass of sympy Function which give the associated divergence of
    the PaVe functions predefined.

    Atributes
    ---------
    This has the same atributtes as Function
    of sympy

    Methods
    -------
    eval(F)
        F: PaVe function
        Return the divergence of the PaVe functions
        predefined

    Example
    -------
    >>> from sympy import symbols
    >>> m = symbols('m',rel=True)
    >>> Div(A0(m))
    m**2*Δe
    '''
    @classmethod
    def eval(cls, F):
        if F.func == A0:
            M = F.args[0]
            return M**2*Δe
        elif F.func == B1_0 or F.func == B2_0 or F.func == B12_0:
            return Δe
        elif F.func == B1_1 or F.func == B12_1:
            # M0, M1 = F.args
            return Δe/2
        elif F.func == B2_1 or F.func == B12_2:
            # M0, M2 = F.args
            return -(Δe/2)

# Cambios PaVe en términos de funciones divergentes y finitas


class PaVetoDivFin(Function):
    '''Subclass of sympy Function to rewrite PaVe functions in terms of
    the finite and divergent part of the corresponding PaVe

    Atributes
    ---------
    This has the same atributtes as Function of sympy

    Methods
    -------
    eval(F)
        F: PaVe Function
        Return the PaVe function in term of the finite and divergent parts

    Example
    -------
    >>> from sympy import symbols
    >>> m = symbols('m',rel=True)
    >>> PaVetoDivFin(A0(m))
    a0(m) + m**2*Δe
    '''
    @classmethod
    def eval(cls, F):
        if F.func == A0:
            args = F.args
            return Div(A0(*args)) + a0(*args)
        elif F.func == B1_0:
            args = F.args
            return Div(B1_0(*args)) + b1_0(*args)
        elif F.func == B2_0:
            args = F.args
            return Div(B2_0(*args)) + b2_0(*args)
        elif F.func == B12_0:
            args = F.args
            return Div(B12_0(*args)) + b12_0(*args)
        elif F.func == B1_1:
            args = F.args
            return Div(B1_1(*args)) + b1_1(*args)
        elif F.func == B2_1:
            args = F.args
            return Div(B2_1(*args)) + b2_1(*args)
        elif F.func == C1:
            # args = F.args
            M0, M1, M2 = F.args
            return (1/ma**2)*(
                b1_0(M0, M1) - b12_0(M1, M2) + (M2**2-M0**2)*C0(M0, M1, M2)
                )
        elif F.func == C2:
            # args = F.args
            M0, M1, M2 = F.args
            return (-1/ma**2)*(
                b2_0(M0, M2) - b12_0(M1, M2) + (M1**2-M0**2)*C0(M0, M1, M2)
                )
        else:
            raise ValueError(f'{F.func} is not defined.')
# definición de xk


_x, _m1, _m2 = symbols('x,m1,m2')
_funcion = _x**2 - ((ma**2 - _m1**2 + _m2**2)/ma**2)*_x + (_m2**2)/ma**2
_sols = solve(_funcion, _x)

# print(_sols[0].subs({_m1:1,_m2:2}))
# print(_sols[0].atoms(Symbol))


def xk(i, M1, M2, mh=ma):
    if i in [1, 2]:
        if (isinstance(M1, (Symbol, Mul, Indexed)) or
                isinstance(M2, (Symbol, Mul, Indexed)) or
                isinstance(mh, (Symbol, Mul, Indexed))):
            return _sols[i-1].subs({_m1: M1, _m2: M2, ma: mh})
        else:
            return _sols[i-1].evalf(30, subs={_m1: M1, _m2: M2, ma: mh})
    else:
        return 'i = a 1 o 2'


xkf = Function('x_k')


# C0 en terminos de R0
def Li2(x0):
    return polylog(2, x0)


def R0(x0, xi):
    return Li2(x0/(x0-xi)) - Li2((x0-1)/(x0-xi))

# R0_aprox = lambda x0,xi: Li2_aprox(x0/(x0-xi)) - Li2_aprox((x0-1)/(x0-xi))


def x0(M0, M2):
    return (M2**2-M0**2)/ma**2


def x3(M0, M1):
    return (-M0**2)/(M1**2-M0**2)

# Definiciones para las funciones b:
# https://www.sciencedirect.com/science/article/pii/S0550321317301785


y, t = symbols('y,t')
def f0(x):
    return integrate(log(1-(t/x)), (t, 0, 1))
def f1(x):
    return 2*integrate(t*log(1-(t/x)), (t, 0, 1))
# convirtiendo f0 y f1 en funciones simbolicas
f0sp = lambdify([y], f0(y), 'sympy')
f1sp = lambdify([y], f1(y), 'sympy')

# soluciones de la ecuación
M0, M1, M2 = symbols('M_0, M_1, M_2', real=True)
ec1 = y**2*mi**2 - y*(mi**2 + M0**2 - M1**2) + M0**2
ec2 = y**2*mj**2 - y*(mj**2 + M0**2 - M2**2) + M0**2
y11, y12 = solve(ec1, y)
y21, y22 = solve(ec2, y)

# Convirtiendo en funciones simbolicas las soluciones yij
y11sp = lambdify([mi, M0, M1], y11, 'sympy')
y12sp = lambdify([mi, M0, M1], y12, 'sympy')
y21sp = lambdify([mj, M0, M2], y21, 'sympy')
y22sp = lambdify([mj, M0, M2], y22, 'sympy')

f01sum = Add(*[f0sp(y1j(mi, M0, M1)) for y1j in [y11sp, y12sp]])
# f01sum

f02sum = Add(*[f0sp(y2j(mj, M0, M2)) for y2j in [y21sp, y22sp]])
# f02sum

f11sum = Add(*[f1sp(y1j(mi, M0, M1)) for y1j in [y11sp, y12sp]])
# f11sum

f12sum = Add(*[f1sp(y2j(mj, M0, M2)) for y2j in [y21sp, y22sp]])
# f12sum


b1_0sp = lambdify([M0, M1], -log(M1**2)-f01sum, 'sympy')
b2_0sp = lambdify([M0, M2], -log(M2**2)-f02sum, 'sympy')
b1_1sp = lambdify(
    [M0, M1], -((1/2)*(-log(M1**2)) - f01sum + (1/2)*f11sum), 'sympy'
    )
b2_1sp = lambdify(
    [M0, M2], (1/2)*(-log(M2**2)) - f02sum + (1/2)*f12sum, 'sympy'
    )


# definiciones para las partes finitas de las PaVe
class PaVe_aprox(Function):
    '''Subclass of sympy Function to show explicitly the  definition of finite
    part of PaVe functions.
    Reference
    ---------
    This definition are given in the approximation given by
    https://arxiv.org/abs/1512.03266v2

    Atributes
    ---------
    This has the same atributtes as Function of sympy

    Methods
    -------
    eval(F)
        F: Finite part of PaVe Function
        Return explicitly definition of finite part of PaVe functions

    Example
    -------
    >>> from sympy import symbols
    >>> m = symbols('m',real=True)
    >>> PaVe_aprox(a0(m))
    m**2*(1+log((ma**2-I*δ)/(m**2-I*δ)))
    '''
    @classmethod
    def eval(cls, F):
        if F.func == a0:
            M = F.args[0]
            return M**2*(1+log((ma**2-I*δ)/(M**2-I*δ)))
        elif F.func == b1_0:
            M0, M1 = F.args
            return b1_0sp(M0, M1)
        elif F.func == b2_0:
            M0, M2 = F.args
            return b2_0sp(M0, M2)
        elif F.func == b1_1:
            M0, M1 = F.args
            return b1_1sp(M0, M1)
        elif F.func == b2_1:
            M0, M2 = F.args
            return b2_1sp(M0, M2)
        elif F.func == b12_0:
            M1, M2 = F.args
            x1, x2 = xkf(1, M1, M2), xkf(2, M1, M2)
            # def log_rewrite(x):
            #     y = 1e30
            #     r = (y*x).expand()
            #     return log(r) - log(y)
            return log((ma**2 - I*δ)/(M1**2 - I*δ))/2 +\
                sum(x*(log(1 - 1/x)) for x in [x1, x2])
        elif F.func == b12_1:
            M1, M2 = F.args
            return (1/(2*ma**2))*(
                M1**2*(1+log(ma**2/M1**2)) - M2**2*(1+log(ma**2/M2**2))
                ) + b12_0(M1, M2)/(2*ma**2)*(M2**2-M1**2 + ma**2)
        elif F.func == b12_2:
            M1, M2 = F.args
            return (1/(2*ma**2))*(
                M1**2*(1+log(ma**2/M1**2)) - M2**2*(1+log(ma**2/M2**2))
                ) + b12_0(M1, M2)/(2*ma**2)*(M2**2-M1**2 - ma**2)
        elif F.func == C0:
            M0, M1, M2 = F.args
            y0 = x0(M0, M2)
            y1 = xkf(1, M1, M2)
            y2 = xkf(2, M1, M2)
            y3 = x3(M0, M1)
            return (R0(y0, y1) + R0(y0, y2) - R0(y0, y3))/ma**2
        else:
            raise ValueError(f'{F.func} is not defined.')
##########################################
# ########################################


def cambiosx(M1, M2, mh):
    return {
        xkf(1, M1, M2): xk(1, M1, M2, mh),
        xkf(2, M1, M2): xk(2, M1, M2, mh)
        }


class PaVe_aprox_evalf(Function):
    '''Subclass of sympy Function to show explicitly the  definition of finite
    part of PaVe functions evaluated in a certain benchmark.
    Reference
    ---------
    This definition are given in the approximation given by
    https://arxiv.org/abs/1512.03266v2

    Atributes
    ---------
    This has the same atributtes as Function of sympy

    Methods
    -------
    eval(F)
        F: Finite part of PaVe Function evaluated
        Return numeric finite part of PaVe functions

    Example
    -------
    >>> from sympy import symbols
    >>> m = symbols('m',real=True)
    >>> PaVe_aprox(a0(1))
    m**2*(1+log((ma**2-I*δ)/(m**2-I*δ)))
    '''
    @classmethod
    def eval(cls, F, mh, mli=0, mlj=0):
        ####################################
        from sympy import And, Number
        are_true = And(*[isinstance(m, (Number)) for m in F.args])
        if are_true:
            pass
        else:
            print(
                'This function is used when the ' +
                'arguments of PaVe functions are numbers')
        #######################################
        m0, m1, m2 = symbols('m_0,m_1,m_2', posiive=True)
        # cambiosx = lambda M1,M2,mh: {xkf(1,M1,M2):xk(1,M1,M2,mh),
        #                     xkf(2,M1,M2):xk(2,M1,M2,mh)}
        if F.func == a0:
            M = F.args[0]
            return PaVe_aprox(a0(m0)).evalf(subs={ma: mh, m0: M})
        elif F.func == b1_0:
            M0, M1 = F.args
            return PaVe_aprox(b1_0(m0, m1)).evalf(subs={
                ma: mh, m0: M0, m1: M1, mi: mli
                })  # b1_0sp(M0,M1)
        elif F.func == b2_0:
            M0, M2 = F.args
            return PaVe_aprox(b2_0(m0, m2)).evalf(
                subs={ma: mh, m0: M0, m2: M2, mj: mlj})
        elif F.func == b1_1:
            M0, M1 = F.args
            return PaVe_aprox(b1_1(m0, m1)).evalf(
                subs={ma: mh, m0: M0, m1: M1, mi: mli})
        elif F.func == b2_1:
            M0, M2 = F.args
            return PaVe_aprox(b2_1(m0, m2)).evalf(
                subs={ma: mh, m0: M0, m2: M2, mi: mli})
        elif F.func == b12_0:
            M1, M2 = F.args
            return PaVe_aprox(b12_0(m1, m2)).subs(
                cambiosx(m1, m2, 125.18)).evalf(subs={ma: mh, m1: M1, m2: M2})
        elif F.func == b12_1:
            M1, M2 = F.args
            cambio = {b12_0(m1, m2): PaVe_aprox(b12_0(m1, m2))}
            return PaVe_aprox(b12_1(m1, m2)).subs(cambio).subs(
                cambiosx(m1, m2, 125.18)).evalf(subs={ma: mh, m1: M1, m2: M2})
        elif F.func == b12_2:
            M1, M2 = F.args
            cambio = {b12_0(m1, m2): PaVe_aprox(b12_0(m1, m2))}
            return PaVe_aprox(b12_2(m1, m2)).subs(cambio).subs(
                cambiosx(m1, m2, 125.18)).evalf(subs={ma: mh, m1: M1, m2: M2})
        # (1/(2*ma**2))*(M1**2*(1+log(ma**2/M1**2)) -
        # M2**2*(1+log(ma**2/M2**2))) +
        # b12_0(M1,M2)/(2*ma**2)*(M2**2-M1**2 - ma**2)
        elif F.func == C0:
            M0, M1, M2 = F.args
            # y0 = x0(M0,M2)
            # y1 = xkf(1,M1,M2)
            # y2 = xkf(2,M1,M2)
            # y3 = x3(M0,M1)
            return PaVe_aprox(C0(m0, m1, m2)).subs(
                cambiosx(m1, m2, 125.18)).evalf(
                    subs={ma: mh, m0: M0, m1: M1, m2: M2})
        # (R0(y0,y1) + R0(y0,y2) - R0(y0,y3))/ma**2
        else:
            raise ValueError(f'{F.func} is not defined.')

# #Funciones para sustituciones de las funciones de PaVe
# Para triangulos


def FuncPaVe(M0, M1, M2):
    return [
        A0(M0), A0(M1), A0(M2), B1_0(M0, M1), B2_0(M0, M2),
        B1_1(M0, M1), B2_1(M0, M2), B12_0(M1, M2),
        C1(M0, M1, M2), C2(M0, M1, M2)
        ]


def funcPaVe(M0, M1, M2):
    return [
        a0(M0), a0(M1), a0(M2), b1_0(M0, M1), b2_0(M0, M2),
        b1_1(M0, M1), b2_1(M0, M2), b12_0(M1, M2), C0(M0, M1, M2)
        ]


def cambiosDivFin(M0, M1, M2):
    return {
        PV: PaVetoDivFin(PV) for PV in FuncPaVe(M0, M1, M2)
        }


def cambios_aprox(M0, M1, M2):
    return {PV: PaVe_aprox(PV) for PV in funcPaVe(M0, M1, M2)}


def cambios_aprox_evalf(M0, M1, M2, mh, mli, mlj):
    return {
        PV: PaVe_aprox_evalf(PV, mh, mli, mlj)
        for PV in funcPaVe(M0, M1, M2)
        }

# Para burbujas
# FuncPaVeBA = lambda M0,M1,M2:
# [A0(M0),A0(M1),A0(M2),B1_0(M0,M1),B2_0(M0,M2),
# B1_1(M0,M1),B2_1(M0,M2),B12_0(M1,M2)]
# funcPaVeBA = lambda M0,M1,M2:
# [a0(M0),a0(M1),a0(M2),b1_0(M0,M1),b2_0(M0,M2),
# b1_1(M0,M1),b2_1(M0,M2),b12_0(M1,M2)]
# cambiosDivFinBA = lambda M0,M1:
# {PV:PaVetoDivFinBA(PV) for PV in FuncPaVeBA(M0,M1,M2)}
# cambios_aproxBA = lambda M0,M1:
# {PV:PaVe_aproxBA(PV) for PV in funcPaVeBA(M0,M1,M2)}


# ##########################################
# Funciones H para las diferentes contribuciones al proceso h->l1,l2
# ##########################################
# Funciones para las contribuciones del tipo FSV
# M0,M1,M2 = symbols('M0,M1,M2',real=True)
HFSV = [0]*9
HFSV[1] = lambda M0, M1, M2: -B12_0(M1, M2) - M0**2*C0(M0, M1, M2) -\
        (mj**2 - 2*ma**2)*C2(M0, M1, M2) -\
        2*mi**2*(-C1(M0, M1, M2) + C2(M0, M1, M2))
HFSV[2] = lambda M0, M1, M2: -mi*mj*(C1(M0, M1, M2) - 2*C2(M0, M1, M2))
HFSV[3] = lambda M0, M1, M2: -mi*M0*(C1(M0, M1, M2) - 2*C0(M0, M1, M2))
HFSV[4] = lambda M0, M1, M2: -mj*M0*(C0(M0, M1, M2) - C2(M0, M1, M2))
##
# Funciones para las contribuciones del tipo FVS
##
HFVS = [0]*9
# HFVS
HFVS[1] = lambda M0, M1, M2: mi*M0*(C0(M0, M1, M2) + C1(M0, M1, M2))
HFVS[2] = lambda M0, M1, M2: - mj*M0*(2*C0(M0, M1, M2) + C2(M0, M1, M2))
HFVS[3] = lambda M0, M1, M2: B12_0(M1, M2) + M0**2*C0(M0, M1, M2) +\
        (2*ma**2 - mi**2-2*mj**2)*C1(M0, M1, M2) + 2*mj**2*C2(M0, M1, M2)
HFVS[4] = lambda M0, M1, M2: -mi*mj*(-2*C1(M0, M1, M2) + C2(M0, M1, M2))
# ##############################################
# Funciones para las contribuciones del tipo FVV
# ##############################################


def XRL(M0, M1, M2):
    return M0**2*(B1_1(M0, M1) - B1_0(M0, M1)) -\
        (A0(M2) + M0**2*B2_0(M0, M2) + mj**2*B2_1(M0, M2)) +\
        (M1**2 + M2**2 - ma**2)*(
            B12_1(M1, M2) +
            M0**2*C1(M0, M1, M2) - B12_0(M1, M2) -
            M0**2*C0(M0, M1, M2) - mj**2*C2(M0, M1, M2))
# XRL(M0,M1,M2)


def XLR(M0, M1, M2):
    return 2*A0(M2) + M0**2*(B2_1(M0, M2) + B2_0(M0, M2)) +\
        A0(M1) + M0**2*B1_0(M0, M1) - mi**2*B1_1(M0, M1) +\
        (M1**2 + M2**2 - ma**2)*(
            B12_2(M1, M2) + M0**2*C2(M0, M1, M2) +
            B12_0(M1, M2) + M0**2*C0(M0, M1, M2) -
            mi**2*C1(M0, M1, M2))
##############################################


D = symbols('D')
HFVV = [0]*9
# HFVV
HFVV[1] = lambda M0, M1, M2: -mi*(D-2)*C1(M0, M1, M2)
# HFVV[1](M0,M1,M2)
HFVV[2] = lambda M0, M1, M2: (D-2)*mj*C2(M0, M1, M2)
# HFVV[2](M0,M1,M2)

HFVV[3] = lambda M0, M1, M2: M0*D*C0(M0, M1, M2)
# HFVV[4](M0,M1,M2)
################################################
# Funciones para las contribuciones del tipo SFF
###############################################
# HSFF = [0]*5
# HSFF[1] = lambda M0,M1,M2: mi*M2*(C1(M0,M1,M2)-C0(M0,M1,M2))
# HSFF[2] =  lambda M0,M1,M2: M2*(M1*C0(M0,M1,M2) - mj*C2(M0,M1,M2))
# HSFF[3] =  lambda M0,M1,M2: B12_0(M1,M2) + M0**2*C0(M0,M1,M2) -
# mi**2*C1(M0,M1,M2) + mj**2*C2(M0,M1,M2) +
# (ma**2 -mi**2 -mj**2)*(C1(M0,M1,M2) - C2(M0,M1,M2) - C0(M0,M1,M2)) -
# mj*M1*(C0(M0,M1,M2)  + C2(M0,M1,M2))
# HSFF[4] =  lambda M0,M1,M2: mi*M1*C1(M0,M1,M2) +
# mi*mj*(C1(M0,M1,M2) - C2(M0,M1,M2) - C0(M0,M1,M2) )

HSFF = [0]*9
HSFF[1] = lambda M0, M1, M2: B12_0(M1, M2) + M0**2*C0(M0, M1, M2) -\
        mi**2*C1(M0, M1, M2) + mj**2*C2(M0, M1, M2)
HSFF[2] = lambda M0, M1, M2: mi*mj*(
    C0(M0, M1, M2) +
    C2(M0, M1, M2) -
    C1(M0, M1, M2))
HSFF[3] = lambda M0, M1, M2: mj*M2*C2(M0, M1, M2)
HSFF[4] = lambda M0, M1, M2: mi*M2*(C0(M0, M1, M2)-C1(M0, M1, M2))
HSFF[5] = lambda M0, M1, M2: mj*M1*(C0(M0, M1, M2) + C2(M0, M1, M2))
HSFF[6] = lambda M0, M1, M2: -mi*M1*C1(M0, M1, M2)
HSFF[7] = lambda M0, M1, M2: M1*M2*C0(M0, M1, M2)

#################################################
# Funciones para las contribuciones del tipo VFF
#################################################
# HVFF = [0]*5

# SLR1 = lambda M0,M1,M2: B1_0(M0,M1) + (M2**2-mj**2)*C0(M0,M1,M2) -
# mi**2*C1(M0,M1,M2) - mj**2*C2(M0,M1,M2) - mj*M1*(C0(M0,M1,M2) +
# C2(M0,M1,M2)) - (ma**2 -mi**2 -mj**2)*(C0(M0,M1,M2)  + C2(M0,M1,M2))

# SRL1 = lambda M0,M1,M2: mi*M1*C1(M0,M1,M2) - mi*mj*(C0(M0,M1,M2) -
# C1(M0,M1,M2) + C2(M0,M1,M2))

# TLR1 = lambda M0,M1,M2: mi*M2*(C1(M0,M1,M2) - C0(M0,M1,M2) )
# TRL1 = lambda M0,M1,M2: M2*(M1*C0(M0,M1,M2) - mj*C2(M0,M1,M2))


# HVFF[1] = lambda M0,M1,M2: -D*SLR1(M0,M1,M2)
# HVFF[2] =  lambda M0,M1,M2: -D*SRL1(M0,M1,M2)
# HVFF[3] = lambda M0,M1,M2: -D*TLR1(M0,M1,M2)
# HVFF[4] =  lambda M0,M1,M2: -D*TRL1(M0,M1,M2)

HVFF = [0]*9
HVFF[1] = lambda M0, M1, M2: -(2-D)*mi*M2*(C0(M0, M1, M2) - C1(M0, M1, M2))
HVFF[2] = lambda M0, M1, M2: -(2-D)*mj*M2*C2(M0, M1, M2)
HVFF[3] = lambda M0, M1, M2: (D-4)*mi*mj*(
    C1(M0, M1, M2) - C0(M0, M1, M2) - C2(M0, M1, M2))
HVFF[4] = lambda M0, M1, M2: -(D*(
    B12_0(M0, M1) + M0**2*C0(M0, M1, M2) +
    mi**2*C2(M0, M1, M2) - mi**2*C1(M0, M1, M2)) +
    4*((ma**2 - mi**2 - mj**2)/2)*(
        C1(M0, M1, M2) - C0(M0, M1, M2) - C2(M0, M1, M2)
        ))
HVFF[5] = lambda M0, M1, M2: (2-D)*mi*M1*C1(M0, M1, M2)
HVFF[6] = lambda M0, M1, M2: -(2-D)*mj*M1*(C0(M0, M1, M2) + C2(M0, M1, M2))
HVFF[7] = lambda M0, M1, M2: -D*M1*M2*C0(M0, M1, M2)

###################################################
# Definiendo las clases de los vertices genericos para este tipo de procesos
###################################################


class VertexHSS():
    '''Class of vertex of three scalars

    Atributes
    ---------
        c:sympy symbols
            c represents the constant coupling among three scalars

    Methods
    -------
    show()
    returns three scalars coupling
    '''
    def __init__(self, c):
        '''
        Parameters
        ----------
            c:sympy symbols
                c represents the constant coupling among three scalars
        '''
        self.c = c

    def __str__(self):
        return f'VertexHSS({self.c!r})'

    def __repr__(self):
        return self.__str__()

    def show(self):
        '''Returns three scalars coupling'''
        return self.c


class VertexHFF(VertexHSS):
    '''Class of vertex of neutral scalar and two fermions.

    Atributes
    ---------
        c:sympy symbols
        c represents the constant coupling among neutral scalar
        and two fermions

    Methods
    -------
    show()
        returns neutral scalar and two fermions coupling
    '''
    # def __init__(self,c):
    #     self.c = c

    def __str__(self):
        return f'VertexHFF({self.c!r})'

    def show(self):
        '''
        Returns Higgs boson and two fermions coupling
        '''
        return self.c


class VertexHSpVm(VertexHSS):
    '''Class of vertex of two scalars and one vector boson

    Atributes
    ---------
        c:sympy symbols
        c represents the constant coupling among two scalars
        and one vector boson

    Methods
    -------
    show()
        returns two scalars and one vector boson coupling
    '''
    # def __init__(self,c):
    #     self.c = c
    def __str__(self):
        return f'VertexHSpVm({self.c!r})'

    def show(self):
        '''Returns two scalars and one vector boson coupling'''
        pmu1, pmu2 = symbols(r'{{p^{+}}},{{p^{a}}}')
        return self.c*(pmu1 - pmu2)


class VertexHVpSm(VertexHSS):
    '''Class of vertex of two scalars and one vector boson

    Atributes
    ---------
        c:sympy symbols
        c represents the constant coupling among two scalars
        and one vector boson

    Methods
    -------
    show()
        returns two scalars and one vector boson coupling
    '''
    # def __init__(self,c):
    #     self.c = c
    def __str__(self):
        return f'VertexHVpSm({self.c!r})'

    def show(self):
        '''Returns two scalars and one vector boson coupling'''
        pmu1, pmu2 = symbols(r'{{p^{a}}},{{p^{-}}}')
        return self.c*(pmu1 - pmu2)


class VertexHVV(VertexHSS):
    '''Class of vertex of one scalar and two vector bosons.

    Atributes
    ---------
        c:sympy symbols
        c represents the constant coupling among one scalar
        and two vector bosons

    Methods
    -------
    show()
        returns one scalar and two vector bosons coupling
    '''
    def __str__(self):
        return f'VertexHVV({self.c!r})'

    def show(self):
        '''Returns one scalar and two vector bosons coupling'''
        gmunu = symbols(r'{{g^{\mu \nu}}}', real=True)
        return self.c*gmunu


class VertexSFF():
    '''Class vertex of one scalar and two fermions.

    Atributes
    ---------
        cR:sympy symbols
            cR is the coefficint of PR in the coupling of one
            scalar and two fermions
        cL:sympy symbols
            cL is the coefficint of PL in the coupling of one
            scalar and two fermions

    Methods
    -------
    show()
        returns one scalar and two fermions
    '''
    def __init__(self, cR, cL):
        '''
        Parameters
        ---------
        cR:sympy symbols
            cR is the coefficint of PR in the coupling of one
            scalar and two fermions
        cL:sympy symbols
            cL is the coefficint of PL in the coupling of one
            scalar and two fermions
        '''
        self.cR = cR
        self.cL = cL
        if self.cL == self.cR:
            self.c = self.cL

    def __str__(self):
        return f'VertexSFF({self.cR!r},{self.cL!r})'

    def __repr__(self):
        return self.__str__()

    def show(self):
        '''Returns one scalar and two fermions'''
        PR, PL = symbols('P_R,P_L', commutative=False)
        cR = self.cR
        cL = self.cL
        return cR*PR + cL*PL


class VertexHF0F0(VertexSFF):
    def __str__(self):
        return f'VertexHF0F0({self.cR!r},{self.cL!r})'


class VertexVFF(VertexSFF):
    '''Class vertex of one vector boson and two fermions.

    Atributes
    ---------
        cR:sympy symbols
            cR is the coefficint of PR in the coupling of one vector boson
            and two fermions
        cL:sympy symbols
            cL is the coefficint of PL in the coupling of one vector boson
            and two fermions

    Methods
    -------
    show()
        returns one vector boson and two fermions
    '''
    # def __init__(self,cR,cL):
    #     self.cR = cR
    #     self.cL = cL

    def __str__(self):
        return f'VertexVFF({self.cR!r},{self.cL!r})'

    def show(self):
        '''Returns one vector boson and two fermions'''
        PR, PL, gamma_mu = symbols(r'P_R,P_L,\gamma_\mu', commutative=False)
        cR = self.cR
        cL = self.cL
        return gamma_mu*(cR*PR + cL*PL)


# ###################################################
# Definiendo las clases para los diferentes diagramas tipo triangulo
# ###################################################


class Triangle():
    '''Represents a trinangle Feynman diagram

    Atributes
    ---------
        v1,v2,v3:some of the classes VertexSSS,VertexVSS,VertexSVV,
        VertexSFF,VertexSVV or VertexhFF.

    Methods
    -------
    show()
        returns
    '''
    def __init__(self, v1, v2, v3, masas):
        self.v1 = v1
        self.v2 = v2
        self.v3 = v3
        self.masas = masas
        self.vertices = [v1, v2, v3]
        self.Cs = [C0(*masas), C1(*masas), C2(*masas)]

    def __str__(self):
        return f'Triangle({self.v1!r}, {self.v2!r},' +\
            ' {self.v3!r}, {self.masas!r})'

    def __repr__(self):
        return self.__str__()

    def AL(self):
        return symbols('M_L')

    def AR(self):
        return symbols('M_R')

    def AL_GIM(self):
        M0, M1, M2 = self.masas
        R = self.AL().subs(cambiosDivFin(M0, M1, M2)).expand()
        return collect(
            Add(*[r for r in R.args if r.has(M0.simplify())]),
            self.Cs, simplify).simplify()

    def AR_GIM(self):
        M0, M1, M2 = self.masas
        R = self.AR().subs(cambiosDivFin(M0, M1, M2)).expand()
        return collect(
            Add(*[r for r in R.args if r.has(M0.simplify())]),
            self.Cs, simplify).simplify()

    # def ML_GIM(self,funcion=simplify):
    #     M0,M1,M2 = self.masas
    #     polyM0 = collect(self.ML().subs(cambiosDivFin(M0,M1,M2)).expand(),
    #     [M0],evaluate=False)
    #     pot = list(polyM0.keys())
    #     if 1 in pot:
    #         pot.remove(1)
    #     else:
    #         pass
    #     if len(pot)>=1:
    #         return collect(Add(*[pt*funcion(polyM0[pt]) for pt in pot]),
    #     self.Cs,simplify)
    #     else:
    #         print('El factor ML de este diagrama no contribuye por
    # el mecanismo de GIM')
    # def MR_GIM(self,funcion=simplify):
    #     M0,M1,M2 = self.masas
    #     polyM0 = collect(self.MR().subs(cambiosDivFin(M0,M1,M2)).expand(),
    #          [M0],evaluate=False)
    #     pot = list(polyM0.keys())
    #     if 1 in pot:
    #         pot.remove(1)
    #     else:
    #         pass
    #     if len(pot)>=1:
    #         return collect(Add(*[pt*funcion(polyM0[pt]) for pt in pot]),
    #         self.Cs,simplify)
    #     else:
    #         print('El factor MR de este diagrama no contribuye
    #              por el mecanismo de GIM')

#    def MLGIMDivFin(self):
#        M0,M1,M2 = self.masas
#        return self.ML_GIM().subs(cambiosDivFin(M0,M1,M2))
#    def MRGIMDivFin(self):
#        M0,M1,M2 = self.masas
#        return self.MR_GIM().subs(cambiosDivFin(M0,M1,M2))

    def Div_AL(self, M):
        M0, M1, M2 = self.masas
        AL = collect(
            self.AL().subs(cambiosDivFin(*self.masas)).expand(),
            [M], evaluate=False)
        # display(list(AL.keys()))
        Lista = []
        for m in AL.keys():
            dicΔe = collect(AL[m], [Δe], evaluate=False)
            claves = dicΔe.keys()
            if Δe in claves:
                Lista.append((dicΔe[Δe]*m).simplify()*Δe)
            else:
                Lista.append(m)
        return Lista

    def Div_MR(self, M):
        M0, M1, M2 = self.masas
        MR = collect(
            self.MR().subs(cambiosDivFin(*self.masas)).expand(),
            [M], evaluate=False)
        # display(list(MR.keys()))
        Lista = []
        for m in MR.keys():
            dicΔe = collect(MR[m], [Δe], evaluate=False)
            claves = dicΔe.keys()
            if Δe in claves:
                Lista.append((dicΔe[Δe]*m).simplify()*Δe)
            else:
                Lista.append(m)
        return Lista

    def width_hl1l2(self):
        ML, MR = self.ML(), self.MR()
        return 1/(8*pi*ma)*sqrt(
            (1 - ((mi**2 + mj**2)/ma)**2)*(1 - ((mi**2 - mj**2)/ma)**2)
            )*(
                (ma**2 - mi**2 - mj**2)*(
                    abs(ML)**2 + abs(MR)**2) - 4*mi*mj*re(ML*conjugate(MR))
                    )


FactorRD = I/(16*pi**2)


class TriangleFSS(Triangle):
    def __str__(self):
        return f'TriangleFSS({self.v1!r}, {self.v2!r},' +\
            ' {self.v3!r}, {self.masas!r})'

    def AL(self):
        v1, v2, v3 = self.vertices
        M0, M1, M2 = self.masas
        return FactorRD*v1.c*(
            mi*v2.cL*v3.cR*C1(M0, M1, M2) -
            mj*v2.cR*v3.cL*C2(M0, M1, M2) +
            M0*v2.cL*v3.cL*C0(M0, M1, M2))

    def AR(self):
        v1, v2, v3 = self.vertices
        M0, M1, M2 = self.masas
        return FactorRD*v1.c*(
            mi*v2.cR*v3.cL*C1(M0, M1, M2) -
            mj*v2.cL*v3.cR*C2(M0, M1, M2) +
            M0*v2.cR*v3.cR*C0(M0, M1, M2))


class TriangleFSV(Triangle):
    def __str__(self):
        return f'TriangleFSV({self.v1!r}, {self.v2!r},' +\
            ' {self.v3!r},{self.masas!r})'

    def AL(self):
        v1, v2, v3 = self.vertices
        M0, M1, M2 = self.masas
        return FactorRD*v1.c*(
            v2.cL*v3.cL*(HFSV[1](M0, M1, M2)) +
            v2.cR*v3.cR*(HFSV[2](M0, M1, M2)) +
            v2.cL*v3.cR*(HFSV[3](M0, M1, M2)) +
            v2.cR*v3.cL*(HFSV[4](M0, M1, M2)))

    def AR(self):
        v1, v2, v3 = self.vertices
        M0, M1, M2 = self.masas
        return FactorRD*v1.c*(
            v2.cR*v3.cR*(HFSV[1](M0, M1, M2)) +
            v2.cL*v3.cL*(HFSV[2](M0, M1, M2)) +
            v2.cR*v3.cL*(HFSV[3](M0, M1, M2)) +
            v2.cL*v3.cR*(HFSV[4](M0, M1, M2)))


class TriangleFVS(Triangle):
    def __str__(self):
        return f'TriangleFVS({self.v1!r}, {self.v2!r},' +\
            ' {self.v3!r},{self.masas!r})'

    def AL(self):
        v1, v2, v3 = self.vertices
        M0, M1, M2 = self.masas
        return -FactorRD*v1.c*(
            v2.cL*v3.cL*(HFVS[1](M0, M1, M2)) +
            v2.cR*v3.cR*(HFVS[2](M0, M1, M2)) +
            v2.cL*v3.cR*(HFVS[3](M0, M1, M2)) +
            v2.cR*v3.cL*(HFVS[4](M0, M1, M2)))

    def AR(self):
        v1, v2, v3 = self.vertices
        M0, M1, M2 = self.masas
        return -FactorRD*v1.c*(
            v2.cR*v3.cR*(HFVS[1](M0, M1, M2)) +
            v2.cL*v3.cL*(HFVS[2](M0, M1, M2)) +
            v2.cR*v3.cL*(HFVS[3](M0, M1, M2)) +
            v2.cL*v3.cR*(HFVS[4](M0, M1, M2)))


class TriangleFVV(Triangle):
    def __str__(self):
        return f'TriangleFVV({self.v1!r}, {self.v2!r},' +\
            ' {self.v3!r},{self.masas!r})'

    def AL(self):
        v1, v2, v3 = self.vertices
        M0, M1, M2 = self.masas
        return FactorRD*v1.c*(
            v2.cL*v3.cL*(HFVV[1](M0, M1, M2)) +
            v2.cR*v3.cR*(HFVV[2](M0, M1, M2)) +
            v2.cL*v3.cR*(HFVV[3](M0, M1, M2)))

    def AR(self):
        v1, v2, v3 = self.vertices
        M0, M1, M2 = self.masas
        return FactorRD*v1.c*(
            v2.cR*v3.cR*(HFVV[1](M0, M1, M2)) +
            v2.cL*v3.cL*(HFVV[2](M0, M1, M2)) +
            v2.cR*v3.cL*(HFVV[3](M0, M1, M2)))


class TriangleSFF(Triangle):
    def __str__(self):
        return f'TriangleSFF({self.v1!r}, {self.v2!r},' +\
            ' {self.v3!r},{self.masas!r})'

    def AL(self):
        v1, v2, v3 = self.vertices
        M0, M1,  M2 = self.masas
        return FactorRD*(
            v1.cR*v2.cL*v3.cL*HSFF[1](M0, M1, M2) +
            v1.cL*v2.cR*v3.cR*HSFF[2](M0, M1, M2) +
            v1.cR*v2.cR*v3.cL*HSFF[3](M0, M1, M2) +
            v1.cL*v2.cL*v3.cR*HSFF[4](M0, M1, M2) +
            v1.cL*v2.cR*v3.cL*HSFF[5](M0, M1, M2) +
            v1.cR*v2.cL*v3.cR*HSFF[6](M0, M1, M2) +
            v1.cL*v2.cL*v3.cL*HSFF[7](M0, M1, M2))

    def AR(self):
        v1, v2, v3 = self.vertices
        M0, M1, M2 = self.masas
        return FactorRD*(
            v1.cL*v2.cR*v3.cR*HSFF[1](M0, M1, M2) +
            v1.cR*v2.cL*v3.cL*HSFF[2](M0, M1, M2) +
            v1.cL*v2.cL*v3.cR*HSFF[3](M0, M1, M2) +
            v1.cR*v2.cR*v3.cL*HSFF[4](M0, M1, M2) +
            v1.cR*v2.cL*v3.cR*HSFF[5](M0, M1, M2) +
            v1.cL*v2.cR*v3.cL*HSFF[6](M0, M1, M2) +
            v1.cR*v2.cR*v3.cR*HSFF[7](M0, M1, M2))


class TriangleVFF(Triangle):
    def __str__(self):
        return f'TriangleVFF({self.v1!r}, {self.v2!r},' +\
            ' {self.v3!r},{self.masas!r})'

    def AL(self):
        v1, v2, v3 = self.vertices
        M0, M1, M2 = self.masas
        return FactorRD*(
            v1.cR*v2.cL*v3.cL*HVFF[1](M0, M1, M2) +
            v1.cL*v2.cR*v3.cR*HVFF[2](M0, M1, M2) +
            v1.cR*v2.cR*v3.cL*HVFF[3](M0, M1, M2) +
            v1.cL*v2.cL*v3.cR*HVFF[4](M0, M1, M2) +
            v1.cL*v2.cL*v3.cL*HVFF[5](M0, M1, M2) +
            v1.cR*v2.cR*v3.cR*HVFF[6](M0, M1, M2) +
            v1.cR*v2.cL*v3.cR*HVFF[7](M0, M1, M2))

    def AR(self):
        v1, v2, v3 = self.vertices
        M0, M1, M2 = self.masas
        return FactorRD*(
            v1.cL*v2.cR*v3.cR*HVFF[1](M0, M1, M2) +
            v1.cR*v2.cL*v3.cL*HVFF[2](M0, M1, M2) +
            v1.cL*v2.cL*v3.cR*HVFF[3](M0, M1, M2) +
            v1.cR*v2.cR*v3.cL*HVFF[4](M0, M1, M2) +
            v1.cR*v2.cR*v3.cR*HVFF[5](M0, M1, M2) +
            v1.cL*v2.cL*v3.cL*HVFF[6](M0, M1, M2) +
            v1.cL*v2.cR*v3.cL*HVFF[7](M0, M1, M2))

# ###############################################
# Definiendo las funciones H para los diferentes diagramas tipo burbuja
################################################
# Funciones para las correcciones de burbuja FV


HFV = [0]*5
HFV[1] = lambda M0, M1: ((mi*mj)/(mi**2 - mj**2))*(D - 2)*B1_1(M0, M1)  # HRR
HFV[2] = lambda M0, M1: ((mi**2)/(mi**2 - mj**2))*(D - 2)*B1_1(M0, M1)  # HLL
HFV[3] = lambda M0, M1: -((mj*M0)/(mi**2 - mj**2))*D*B1_0(M0, M1)  # HRL
HFV[4] = lambda M0, M1: -((mi*M0)/(mi**2 - mj**2))*D*B1_0(M0, M1)  # HLR

# Funciones para las correcciones de burbuja VF


def FuncVF1(M0, M2):
    return (D - 2)*B2_1(M0, M2) +\
        (1/M2**2)*(
            3*A0(M2) + 2*M0**2*B2_0(M0, M2) +
            (M0**2 + mj**2)*B2_1(M0, M2))


def FuncVF2(M0, M2):
    return (D - 1)*B2_0(M0, M2) - A0(M0)/M2**2


HVF = [0]*5
HVF[1] = lambda M0, M2: -((mj**2)/(mj**2 - mi**2))*(D - 2)*B2_1(M0, M2)  # HRR
HVF[2] = lambda M0, M2: -((mi*mj)/(mj**2 - mi**2))*(D - 2)*B2_1(M0, M2)  # HLL
HVF[3] = lambda M0, M2: -((mi*M0)/(mj**2 - mi**2))*D*B2_0(M0, M2)  # HRL
HVF[4] = lambda M0, M2: -((mj*M0)/(mj**2 - mi**2))*D*B2_0(M0, M2)  # HLR

# Funciones para las correcciones de burbuja FS
HFS = [0]*5
HFS[1] = lambda M0, M1: ((mj*M0)/(mi**2 - mj**2))*B1_0(M0, M1)  # HRR
HFS[2] = lambda M0, M1: ((mi*M0)/(mi**2 - mj**2))*B1_0(M0, M1)  # HLL
HFS[3] = lambda M0, M1: ((mi*mj)/(mi**2 - mj**2))*B1_1(M0, M1)  # HRL
HFS[4] = lambda M0, M1: ((mi**2)/(mi**2 - mj**2))*B1_1(M0, M1)  # HLR

# Funciones para las correcciones de burbuja SF
HSF = [0]*5
HSF[1] = lambda M0, M2: ((mi*M0)/(mj**2 - mi**2))*B2_0(M0, M2)  # HRR
HSF[2] = lambda M0, M2: ((mj*M0)/(mj**2 - mi**2))*B2_0(M0, M2)  # HLL
HSF[3] = lambda M0, M2: ((-mj**2)/(mj**2 - mi**2))*B2_1(M0, M2)  # HRL
HSF[4] = lambda M0, M2: ((-mi*mj)/(mj**2 - mi**2))*B2_1(M0, M2)  # HLR

# #####################################################
# Definiendo las clases para los diferentes diagramas tipo burbuja
# #####################################################


class Bubble():
    def __init__(self, v1, v2, v3, masas):
        self.v1 = v1
        self.v2 = v2
        self.v3 = v3
        self.masas = masas
        self.vertices = [v1, v2, v3]

    def __str__(self):
        return f'Bubble({self.v1!r}, {self.v2!r},' +\
            ' {self.v3!r},{self.masas!r})'

    def __repr__(self):
        return self.__str__()

    def AL(self):
        return symbols('A_L')

    def AR(self):
        return symbols('A_R')

#    def MLGIMDivFin(self):
#        M0,M1,M2 = self.masas
#        return self.ML_GIM().subs(cambiosDivFin(M0,M1,M2))
#    def MRGIMDivFin(self):
#        M0,M1,M2 = self.masas
#        return self.MR_GIM().subs(cambiosDivFin(M0,M1,M2))
    def width_hl1l2(self):
        ML, MR = self.AL(), self.AR()
        return 1/(8*pi*ma)*sqrt(
            (1 - ((mi**2+mj**2)/ma)**2)*(1-((mi**2-mj**2)/ma)**2))*(
                (ma**2 - mi**2 - mj**2)*(
                    abs(ML)**2 + abs(MR)**2)-4*mi*mj*re(ML*conjugate(MR)))


class BubbleFV(Bubble):
    def __str__(self):
        return f'BubbleFV({self.v1!r}, {self.v2!r},' +\
            ' {self.v3!r},{self.masas!r})'

    def AL(self):
        v1, v2, v3 = self.vertices
        M0, M1 = self.masas
        return FactorRD*v1.c*(
            v2.cL*v3.cL*(HFV[1](M0, M1)) +
            v2.cR*v3.cR*(HFV[2](M0, M1)) +
            v2.cL*v3.cR*(HFV[3](M0, M1)) +
            v2.cR*v3.cL*(HFV[4](M0, M1)))

    def AR(self):
        v1, v2, v3 = self.vertices
        M0, M1 = self.masas
        return FactorRD*v1.c*(
            v2.cR*v3.cR*(HFV[1](M0, M1)) +
            v2.cL*v3.cL*(HFV[2](M0, M1)) +
            v2.cR*v3.cL*(HFV[3](M0, M1)) +
            v2.cL*v3.cR*(HFV[4](M0, M1)))


class BubbleVF(Bubble):
    def __str__(self):
        return f'BubbleVF({self.v1!r}, {self.v2!r},' +\
            ' {self.v3!r},{self.masas!r})'

    def AL(self):
        v1, v2, v3 = self.vertices
        M0, M2 = self.masas
        return FactorRD*v1.c*(
            v2.cL*v3.cL*(HVF[1](M0, M2)) +
            v2.cR*v3.cR*(HVF[2](M0, M2)) +
            v2.cL*v3.cR*(HVF[3](M0, M2)) +
            v2.cR*v3.cL*(HVF[4](M0, M2)))

    def AR(self):
        v1, v2, v3 = self.vertices
        M0, M2 = self.masas
        return FactorRD*v1.c*(
            v2.cR*v3.cR*(HVF[1](M0, M2)) +
            v2.cL*v3.cL*(HVF[2](M0, M2)) +
            v2.cR*v3.cL*(HVF[3](M0, M2)) +
            v2.cL*v3.cR*(HVF[4](M0, M2)))


class BubbleFS(Bubble):
    def __str__(self):
        return f'BubbleFS({self.v1!r}, {self.v2!r},' +\
            ' {self.v3!r},{self.masas!r})'

    def AL(self):
        v1, v2, v3 = self.vertices
        M0, M1 = self.masas
        return FactorRD*v1.c*(
            v2.cL*v3.cL*(HFS[1](M0, M1)) +
            v2.cR*v3.cR*(HFS[2](M0, M1)) +
            v2.cL*v3.cR*(HFS[3](M0, M1)) +
            v2.cR*v3.cL*(HFS[4](M0, M1)))

    def AR(self):
        v1, v2, v3 = self.vertices
        M0, M1 = self.masas
        return FactorRD*v1.c*(
            v2.cR*v3.cR*(HFS[1](M0, M1)) +
            v2.cL*v3.cL*(HFS[2](M0, M1)) +
            v2.cR*v3.cL*(HFS[3](M0, M1)) +
            v2.cL*v3.cR*(HFS[4](M0, M1)))


class BubbleSF(Bubble):
    def __str__(self):
        return f'BubbleSF({self.v1!r}, {self.v2!r},' +\
            ' {self.v3!r},{self.masas!r})'

    def AL(self):
        v1, v2, v3 = self.vertices
        M0, M2 = self.masas
        return FactorRD*v1.c*(
            v2.cL*v3.cL*(HSF[1](M0, M2)) +
            v2.cR*v3.cR*(HSF[2](M0, M2)) +
            v2.cL*v3.cR*(HSF[3](M0, M2)) +
            v2.cR*v3.cL*(HSF[4](M0, M2)))

    def AR(self):
        v1, v2, v3 = self.vertices
        M0, M2 = self.masas
        return FactorRD*v1.c*(
            v2.cR*v3.cR*(HSF[1](M0, M2)) +
            v2.cL*v3.cL*(HSF[2](M0, M2)) +
            v2.cR*v3.cL*(HSF[3](M0, M2)) +
            v2.cL*v3.cR*(HSF[4](M0, M2)))

# #########################################
# Width and BR h -> li lj
# ########################################


def Γhlilj(ML, MR, ma=125.18, mi=1.777, mj=0.1507):
    '''
    Width decay to H_r -> l_a l_b
    '''
    maij = (1 - ((mi**2 + mj**2)/ma)**2)*(1 - ((mi**2 - mj**2)/ma)**2)
    widthij = 1/(8*np.pi*ma)*np.sqrt(maij)*(
        (ma**2 - mi**2 - mj**2)*(np.abs(ML)**2 + np.abs(MR)**2) -
        4*mi*mj*np.real(ML*np.conj(MR)))
    return np.nan_to_num(widthij)


# def BRhlilj(ML,MR,ma=125.18,mi=1.777,mj=0.1507):
#    return np.nan_to_num(Γhlilj(ML ,MR,ma,mi,mj)/
#     (Γhlilj(ML ,MR,ma,mi,mj)+ 4.07e-3))

if __name__ == '__main__':
    print('All right LFVHDFeynGv3')
